package com.example.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.params.ColorSpaceTransform;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;


public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        final EditText your_name        = (EditText) findViewById(R.id.your_name);
        final EditText your_email       = (EditText) findViewById(R.id.your_email);
        final EditText your_phone     = (EditText) findViewById(R.id.your_phone);
        final EditText your_address     = (EditText) findViewById(R.id.your_address);
        Button email = (Button) findViewById(R.id.post_message);


        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name      = your_name.getText().toString();
                String email     = your_email.getText().toString();
                String phone   = your_phone.getText().toString();
                String address   = your_address.getText().toString();

                if (TextUtils.isEmpty(name)){
                    your_name.setError("Enter Your Name");
                    your_name.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(phone)){
                    your_phone.setError("Enter Your Phone");
                    your_phone.requestFocus();
                    return;
                }

                if (your_phone.length()!=10){
                    your_phone.setError("Invalid Number");
                    your_phone.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(address)){
                    your_address.setError("Enter Your Address");
                    your_address.requestFocus();
                    return;
                }


                Intent sendEmail = new Intent(android.content.Intent.ACTION_SEND);

                /* Fill it with Data */
                sendEmail.setType("plain/text");
                sendEmail.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"gr8.pra@gmail.com"});
                sendEmail.putExtra(android.content.Intent.EXTRA_PHONE_NUMBER, phone);
                sendEmail.putExtra(android.content.Intent.EXTRA_TEXT,
                        "Your Name: "+name+'\n'+"Your Email: "+email+'\n'+"Your Phone.: "+phone+'\n'+"Your Address: "+ address);

                /* Send it off to the Activity-Chooser */
                startActivity(Intent.createChooser(sendEmail, "Send mail..."));


            }
        });




    }


}
