package com.example.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    Button button2, button3;
    EditText ed1,ed2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        ed1 = (EditText) findViewById(R.id.editText1);
        ed2 = (EditText)findViewById(R.id.editText2);


        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override // to override the method
                    public void onClick(View v) {


                        if(ed1.getText().toString().equals("admin") &&
                                ed2.getText().toString().equals("admin")) {
                            Toast.makeText(getApplicationContext(),
                                    "Welcome...",Toast.LENGTH_SHORT).show();
                            openActivity2();

                        }else {
                            Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }

    public void openActivity2() {
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }
}

