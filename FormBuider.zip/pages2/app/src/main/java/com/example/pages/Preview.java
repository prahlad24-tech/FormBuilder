package com.example.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Preview extends AppCompatActivity {

    Button closeButton;
    AlertDialog.Builder builder;

TextView textview ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);



        Intent intent = getIntent();
        final String text11 = intent.getStringExtra(Activity2.EXTRA_TEXT1);
        final String text12 = intent.getStringExtra(Activity2.EXTRA_TEXT2);
        final String text13 = intent.getStringExtra(Activity2.EXTRA_TEXT3);
        final String text14 = intent.getStringExtra(Activity2.EXTRA_TEXT4);
        final String text15 = intent.getStringExtra(Activity2.EXTRA_TEXT5);


        TextView text1 = (TextView)findViewById(R.id.textView1);
        text1.setText("Name: "+text11);

        TextView text2 = (TextView)findViewById(R.id.textView2);
        text2.setText("Address: "+text12);

        TextView text3 = (TextView)findViewById(R.id.textView3);
        text3.setText("E-mail: "+text13);

        TextView text4 = (TextView)findViewById(R.id.textView4);
        text4.setText("DOB: "+text14);


        TextView text5 = (TextView)findViewById(R.id.textView5);
        text5.setText("Phone: "+text15);



        TextView text6 = (TextView) findViewById(R.id.info_text1);
        text6.setText("Preview");

        closeButton = (Button) findViewById(R.id.button);
        builder = new AlertDialog.Builder(this);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Uncomment the below code to Set the message and title from the strings.xml file
                builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

                //Setting message manually and performing action on button click
                builder.setMessage("Do you want to change the form data ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("FormBuilder");
                alert.show();
            }
        });


    }

}
