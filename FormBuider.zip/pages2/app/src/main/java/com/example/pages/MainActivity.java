package com.example.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    Button button1, button2;
    EditText ed1,ed2;
    public static final String EXTRA_TEXT = "com.example.pages.EXTRA_TEXT";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button);
        button2 = (Button) findViewById(R.id.button2);

        ed1 = (EditText) findViewById(R.id.username);
        ed2 = (EditText)findViewById(R.id.password);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();

            }
        });



        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override // to override the method
                    public void onClick(View v) {


                        if(ed1.getText().toString().equals("user") &&
                                ed2.getText().toString().equals("user")) {
                            Toast.makeText(getApplicationContext(),
                                    "Welcome...",Toast.LENGTH_SHORT).show();
                            openActivity2();

                        }else {
                            Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }

    public void openActivity2() {
        EditText editText1  = (EditText) findViewById(R.id.username);
        String text  = editText1.getText().toString();
        Intent intent = new Intent(MainActivity.this, Activity2.class);
        intent.putExtra(EXTRA_TEXT,text);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);


    }

}

