package com.example.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.params.ColorSpaceTransform;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Activity2 extends AppCompatActivity implements
        View.OnClickListener{

    EditText ed1;
    public static final String EXTRA_TEXT1 = "com.example.pages.EXTRA_TEXT1";
    public static final String EXTRA_TEXT2 = "com.example.pages.EXTRA_TEXT2";
    public static final String EXTRA_TEXT3 = "com.example.pages.EXTRA_TEXT3";
    public static final String EXTRA_TEXT4 = "com.example.pages.EXTRA_TEXT4";
    public static final String EXTRA_TEXT5 = "com.example.pages.EXTRA_TEXT5";


    Button btnDatePicker, btnTimePicker;
    EditText txtDate;
    CheckBox C1;
    private int mYear, mMonth, mDay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Intent intent = getIntent();
        final String text1 = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        btnDatePicker=(Button)findViewById(R.id.btn_date);
        txtDate=(EditText)findViewById(R.id.in_date);
        C1 = (CheckBox) findViewById(R.id.checkBox) ;
        btnDatePicker.setOnClickListener(this);

        final EditText your_email = (EditText) findViewById(R.id.your_email);
        final EditText your_phone = (EditText) findViewById(R.id.your_phone);
        final EditText your_address = (EditText) findViewById(R.id.your_address);
        final EditText your_dob = (EditText) findViewById(R.id.in_date);

        ed1 = (EditText) findViewById(R.id.your_name);

        Button email = (Button) findViewById(R.id.post_message);
        Button next = (Button) findViewById(R.id.message);

        TextView text = (TextView) findViewById(R.id.info_text);
        text.setText("Hi '"+text1+"'!\nPlease fill the details below");
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.textslidein);
        text.startAnimation(anim);

        next.setOnClickListener(
                new View.OnClickListener() {
                    @Override // to override the method
                    public void onClick(View v) {
                       openActivity3();

                    }
                });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ed1.getText().toString();
                String email = your_email.getText().toString();
                String phone = your_phone.getText().toString();
                String address = your_address.getText().toString();
                String dob = your_dob.getText().toString();


                if (TextUtils.isEmpty(name)) {
                    ed1.setError("Enter Your Name");
                    ed1.requestFocus();
                }

                Boolean onError = false;
                if (!isValidEmail(email)) {
                    onError = true;
                    your_email.setError("Invalid Email");
                }

                if (TextUtils.isEmpty(email)) {
                    ed1.setError("Enter Your E-mail");
                    ed1.requestFocus();
                }


                if (TextUtils.isEmpty(phone)) {
                    your_phone.setError("Enter Your Phone");
                    your_phone.requestFocus();
                }

                if (your_phone.length() != 10) {
                    your_phone.setError("Invalid Number");
                    your_phone.requestFocus();
                }
                if (TextUtils.isEmpty(address)) {
                    your_address.setError("Enter Your Address");
                    your_address.requestFocus();

                }
                if (TextUtils.isEmpty(dob)) {
                    your_dob.setError("Enter Your DOB");
                    your_dob.requestFocus();
                }
                Intent sendEmail = new Intent(android.content.Intent.ACTION_SEND);
                /* Fill it with Data */
                sendEmail.setType("plain/text");
                sendEmail.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"gr8.pra@gmail.com"});
                sendEmail.putExtra(android.content.Intent.EXTRA_PHONE_NUMBER, phone);
                sendEmail.putExtra(android.content.Intent.EXTRA_TEXT,
                 "User ID" + text1 + "Your Name: " + name + '\n' + "Your Email: " + email + '\n' + "Your Phone.: " + phone + '\n' + "Your Address: " + address+ '\n'+ "Your Date of Birth: "+dob);
                if(C1.isChecked())
                {
                /* Send it off to the Activity-Chooser */
                Toast.makeText(getApplicationContext(), "User ID: "+text1+"\nName: "+name+"\nEmail: "+email+"\nPhone No.: "+phone+"\nDate of Birth: "+dob+"\nAddress: "+address, Toast.LENGTH_SHORT).show();

                startActivity(Intent.createChooser(sendEmail, "Send mail..."));
                }else {
                Toast.makeText(getApplicationContext(), "Please Select Terms and Conditions", Toast.LENGTH_SHORT).show();
                }
            }
        });
        }
    public void openActivity3(){

        EditText edit1  = (EditText) findViewById(R.id.your_name);
        EditText edit2  = (EditText) findViewById(R.id.your_address);
        EditText edit3  = (EditText) findViewById(R.id.your_email);
        EditText edit4  = (EditText) findViewById(R.id.in_date);
        EditText edit5  = (EditText) findViewById(R.id.your_phone);

        String text1  = edit1.getText().toString();
        String text2  = edit2.getText().toString();
        String text3  = edit3.getText().toString();
        String text4  = edit4.getText().toString();
        String text5  = edit5.getText().toString();



        Intent intent = new Intent(this, Preview.class);
        intent.putExtra(EXTRA_TEXT1,text1);
        intent.putExtra(EXTRA_TEXT2,text2);
        intent.putExtra(EXTRA_TEXT3,text3);
        intent.putExtra(EXTRA_TEXT4,text4);
        intent.putExtra(EXTRA_TEXT5,text5);

        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();


    }



    @Override
    public void onClick(View v) {
            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
    }

    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }


}